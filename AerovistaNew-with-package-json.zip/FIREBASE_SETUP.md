# Firebase setup for Project AerovistaNew

This ZIP adds the Firebase Flutter dependencies and a safe initialization foundation for:
- Firebase Authentication
- Cloud Firestore

It does **not** create a Firebase project or include credentials. You must create/use a Firebase project in your own Google account.

## 1. Create the Firebase project
1. Open https://console.firebase.google.com/ in a browser and sign in.
2. Create a project (or choose an existing one).
3. In Project settings, add an Android app with package name: `com.aerovistanew.app`.
4. Copy the values for the Android app: API key, App ID, sender ID, and project ID. Auth domain and storage bucket are optional for this scaffold.
5. In Firebase Authentication, enable the sign-in providers you intend to use.
6. In Firestore Database, create a database and set appropriate security rules before storing real user data.

## 2. Add values to GitHub Actions secrets
In the GitHub repository `project-aerovistanew`, open Settings > Secrets and variables > Actions > New repository secret.
Create these secrets (values come from Firebase Project settings):
- `FIREBASE_API_KEY`
- `FIREBASE_APP_ID`
- `FIREBASE_MESSAGING_SENDER_ID`
- `FIREBASE_PROJECT_ID`
- `FIREBASE_AUTH_DOMAIN` (optional)
- `FIREBASE_STORAGE_BUCKET` (optional)

Do not paste service-account private keys or other server secrets into the Flutter app. Firebase client config is not a substitute for Firestore security rules.

## 3. Build
Run Actions > Build AerovistaNew APKs > Run workflow. The build will still complete without Firebase secrets, but Firebase remains uninitialized. With the required secrets set, the app initializes Firebase at startup.

## Current status
This is a Firebase-ready base, not a fully configured live backend. The current app UI has not yet been wired to login or Firestore screens. Those features must be implemented separately.
